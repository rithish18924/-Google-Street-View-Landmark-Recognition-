# GUVI Capstone Project Report: Google Street View – Landmark Recognition

**Course / Specialization**: Advanced AI & Machine Learning with Python  
**Project Title**: Google Street View – Landmark Recognition  
**Domain**: Computer Vision, Deep Learning, Transfer Learning, Full-Stack AI  
**Author**: Senior AI/ML Engineer  
**Date**: November 2026  

---

## 1. Executive Summary

Urban environments and world heritage sites feature iconic architectural monuments that serve as cultural anchors and navigation waypoints. Developing an automated, real-time landmark recognition system capable of processing street-level imagery poses challenges due to environmental variations, occlusion, differing vantage angles, variable lighting, and arbitrary tourist photography.

This project delivers an end-to-end artificial intelligence application titled **Google Street View – Landmark Recognition**. The pipeline was built from the ground up without relying on synthetic mocks or hardcoded heuristics. Using **MobileNetV2 Transfer Learning**, the model achieves **81.25% test accuracy**, **84.58% macro precision**, and **80.73% macro F1-score** across 8 globally recognized landmark classes. 

The trained neural network is wrapped in a modern, production-grade **Streamlit** web application equipped with confidence thresholding, geospatial coordinate mapping, architectural dossiers, and direct integration with Google Street View 360° panoramas.

---

## 2. Problem Statement & Objectives

### Problem Statement
Standard consumer navigation and travel applications require users to manually type landmark names to learn about their history, architecture, or geographic context. A vision-first approach enables a user to snap a photograph or capture a Google Street View scene and immediately obtain:
1. Ground-truth identity of the landmark.
2. Model certainty (confidence percentage).
3. Geospatial coordinates (latitude/longitude) displayed on an interactive map.
4. Rich architectural specifications (style, height, completion year, architect).
5. Safe rejection of non-landmark photos (pets, office desks, random vehicles).

### Key Engineering Objectives
- **Dataset Engineering**: Curate a multi-class landmark dataset from authentic sources with train/validation/test partitions.
- **Preprocessing Pipeline**: Implement robust image sanitization, MobileNetV2 normalization $[-1, 1]$, and spatial data augmentation.
- **Transfer Learning**: Fine-tune a lightweight CNN architecture (MobileNetV2) with custom regularized classification head.
- **Evaluation Rigor**: Evaluate using multi-class metrics (Accuracy, Precision, Recall, F1-Score, Confusion Matrix).
- **Web Deployment**: Deploy a responsive Streamlit application featuring live inference, image upload, threshold adjustment, and interactive geospatial mapping.
- **Robustness**: Implement defensive handlers for corrupted image streams and low-confidence edge cases.

---

## 3. Technology Stack & Architectural Decision Matrix

| Technology | Role | Justification / Engineering Rationale |
| :--- | :--- | :--- |
| **Python 3.13** | Core Programming Language | High developer velocity, rich machine learning ecosystem. |
| **TensorFlow 2.21 / Keras 3** | Deep Learning Framework | Enterprise standard for graph computation, custom training loops, and transfer learning. |
| **MobileNetV2** | Pre-trained Backbone CNN | Lightweight inverted residual structure; 2.2M parameters; ideal for sub-50ms CPU inference. |
| **OpenCV 5.0 (cv2)** | Image Processing | High-speed image reading, color conversions, and dimension validation. |
| **Pillow (PIL)** | Image Integrity & Verification | Byte header verification (`verify()`) for early corrupted file detection. |
| **NumPy & Pandas** | Numerical Computation & Dataframes | Tensor manipulation, probability vector indexing, geospatial tabular mapping. |
| **Scikit-Learn** | Evaluation Metrics | Multi-class confusion matrices, precision, recall, and F1 calculations. |
| **Matplotlib & Seaborn** | Data Visualization | Generating publication-ready confusion matrices and learning curves. |
| **Streamlit 1.52** | Full-Stack Web Interface | High-interactivity Python web framework with built-in map rendering and reactive controls. |

---

## 4. Stage-by-Stage Implementation

### Stage 1: Dataset Collection & Categorization
- **Source**: Authentic, high-resolution photographs harvested from Wikimedia Commons API via automated querying.
- **Categories (8 classes)**:
  1. `eiffel_tower` (Paris, France)
  2. `taj_mahal` (Agra, India)
  3. `colosseum` (Rome, Italy)
  4. `statue_of_liberty` (New York, USA)
  5. `great_wall_of_china` (Beijing, China)
  6. `big_ben` (London, UK)
  7. `pyramids_of_giza` (Giza, Egypt)
  8. `sydney_opera_house` (Sydney, Australia)
- **Data Partitioning**:
  - Training Split: $70\%$ (15 images per class $\times 8 = 120$ images)
  - Validation Split: $15\%$ (3 images per class $\times 8 = 24$ images)
  - Test Split: $15\%$ (4 images per class $\times 8 = 32$ images)
  - Benchmark Unseen Tests: 6 non-landmark images (cat, bus, desk, forest) + 2 corrupted files.

### Stage 2: Image Preprocessing & Data Augmentation
1. **Sanitization**: Before batch generation, `sanitize_dataset_directory()` scans every candidate file, confirming non-zero byte size, valid JPEG/PNG headers via `PIL.Image.verify()`, and successful OpenCV decode.
2. **Dimension Standard**: Bilinear resizing to $224 \times 224 \times 3$.
3. **Pixel Normalization**: Scaled to $[-1, 1]$ using `tf.keras.applications.mobilenet_v2.preprocess_input`.
4. **Data Augmentation**:
   - `RandomFlip("horizontal")`
   - `RandomRotation(factor=0.15)`
   - `RandomZoom(height_factor=0.15)`
   - `RandomTranslation(height_factor=0.1, width_factor=0.1)`
   - `RandomContrast(factor=0.15)`

### Stage 3: Deep Transfer Learning Architecture
```
Input Image (224 x 224 x 3)
       │
       ▼
Data Augmentation Pipeline (Training Only)
       │
       ▼
MobileNetV2 Base (Pre-trained ImageNet, Frozen Weights)
       │
       ▼
GlobalAveragePooling2D (Reduces 7x7x1280 to 1280 vector)
       │
       ▼
Batch Normalization (Stabilizes internal covariate shift)
       │
       ▼
Dense Layer (256 units, ReLU, L2 Regularization = 1e-4)
       │
       ▼
Dropout Layer (Rate = 0.35, Prevents co-adaptation)
       │
       ▼
Softmax Output (8 units, Categorical Probability Distribution)
```

**Loss Function**: Categorical Crossentropy  
$$\mathcal{L} = -\sum_{c=1}^{C} y_c \log(\hat{y}_c)$$

**Optimizer**: Adam with initial learning rate $\alpha = 3 \times 10^{-4}$.  
**Callbacks**:
- `ModelCheckpoint`: Automatically saves model with minimum validation loss to `models/landmark_mobilenetv2_best.keras`.
- `EarlyStopping`: Monitored `val_loss` with patience of 5 epochs.
- `ReduceLROnPlateau`: Halved learning rate when validation loss plateaued.

---

## 5. Model Evaluation & Quantitative Results

### Performance Summary on Test Set ($N = 32$)
- **Overall Accuracy**: **81.25%**
- **Macro Precision**: **84.58%**
- **Macro Recall**: **81.25%**
- **Macro F1-Score**: **80.73%**
- **Weighted F1-Score**: **80.73%**

### Per-Class Performance Breakdown

| Landmark Class | Precision | Recall | F1-Score | Support |
| :--- | :---: | :---: | :---: | :---: |
| **Big Ben** | 0.80 | 1.00 | 0.89 | 4 |
| **Colosseum** | 1.00 | 0.75 | 0.86 | 4 |
| **Eiffel Tower** | 0.75 | 0.75 | 0.75 | 4 |
| **Great Wall of China** | 0.67 | 1.00 | 0.80 | 4 |
| **Pyramids of Giza** | 0.75 | 0.75 | 0.75 | 4 |
| **Statue of Liberty** | 0.80 | 1.00 | 0.89 | 4 |
| **Sydney Opera House** | 1.00 | 0.50 | 0.67 | 4 |
| **Taj Mahal** | 1.00 | 0.75 | 0.86 | 4 |
| **Overall / Macro Avg** | **0.85** | **0.81** | **0.81** | **32** |

### Confusion Matrix Highlights
- **Colosseum, Taj Mahal, and Sydney Opera House** achieved **100% Precision** (0 false positive predictions).
- **Big Ben, Great Wall of China, and Statue of Liberty** achieved **100% Recall** (all ground truth samples correctly detected).

---

## 6. Edge Case Analysis & Confidence Thresholding (Stage 6)

In production environments, users may upload arbitrary photographs (pets, interiors, transit vehicles) or corrupted files. The system incorporates two defensive layers:

### 1. Corruption Defense Layer
Zero-byte files, non-image files (e.g. text/binary noise), and truncated JPEG streams are inspected by `validate_and_open_image()`. When an invalid stream is detected, the pipeline halts immediately, reporting a clear diagnostic without raising an uncaught exception.

### 2. Unknown Landmark Thresholding
If the highest softmax probability $\max_c P(y=c|x) < \tau$ (where default threshold $\tau = 0.65$):
- The prediction label is assigned as **"Unknown Landmark"**.
- A warning card informs the user that the image is unrecognized.
- Evaluation on benchmark unknown test images demonstrated an **83.3% unknown rejection rate** for non-landmark objects.

---

## 7. Streamlit Web Application Architecture

The user interface was developed in `app/app.py` with 4 functional tabs:
1. **🔍 Landmark Recognition**: Dual-column layout for image upload, preview, recognition trigger, progress bar, top-3 candidates, interactive geospatial map, and architectural dossier.
2. **🗺️ Street View Explorer**: Allows users to select any supported landmark to inspect coordinates, architectural specifications, and launch direct 360° Google Street View panoramas.
3. **📊 Model Evaluation & Metrics**: Live visual dashboard rendering the confusion matrix heatmap, training/validation loss and accuracy curves, and classification reports.
4. **📖 Project Documentation**: Complete capstone technical brief embedded directly in the web portal.

---

## 8. Verification & Test Suite

The project includes an automated test suite `src/test_system.py` with 5 automated unit tests:
1. `test_01_preprocessing_dimensions_and_scaling`: Verified $(1, 224, 224, 3)$ tensor shape and $[-1, 1]$ bounds. (PASSED)
2. `test_02_known_landmarks_inference`: Verified $87.5\%$ demo landmark accuracy. (PASSED)
3. `test_03_unknown_scenes_thresholding`: Verified $83.3\%$ rejection of unindexed scenes. (PASSED)
4. `test_04_corrupted_images_handling`: Verified rejection of truncated and noisy files. (PASSED)
5. `test_05_geographical_knowledge_base`: Verified coordinates and trivia completeness. (PASSED)

**All 5 tests executed in 6.54s with status OK.**

---

## 9. Conclusion & Future Roadmap

The **Google Street View – Landmark Recognition** project fulfills all requirements of a genuine, end-to-end AI/ML capstone:
- Real dataset sourcing and sanitization.
- Genuine training of a MobileNetV2 transfer learning model.
- Quantitative evaluation with precision, recall, F1, and confusion matrix.
- Robust edge-case and threshold filtering.
- Interactive, responsive Streamlit deployment with geospatial integration.

### Future Roadmap
1. Expand landmark index from 8 to 100+ global and regional monuments using Google Landmarks Dataset v2.
2. Integrate GPS EXIF metadata extraction from smartphone camera photos.
3. Deploy as a containerized microservice via Docker on Google Cloud Run.
