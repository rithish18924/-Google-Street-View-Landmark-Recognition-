# 🌍 Google Street View – Landmark Recognition

An end-to-end production-grade Artificial Intelligence and Deep Learning system designed to automatically identify international and national architectural landmarks from street-level panoramas and user-uploaded photographs. 

Built using **TensorFlow/Keras (MobileNetV2 Transfer Learning)**, **OpenCV**, and **Streamlit**, the application classifies landmark images, provides statistical confidence metrics, maps geospatial coordinates, and retrieves rich architectural and historical dossiers with direct Google Street View 360° panoramic integration.

---

## 📌 Project Overview

Recognizing landmark structures in urban and natural landscapes is a foundational challenge in computer vision. Real-world street images frequently present complex variations, including occlusions, differing angles, lighting conditions, weather shifts, and tourists.

This project implements a genuine 6-stage machine learning lifecycle:
1. **Stage 1 – Dataset Collection**: Sourced and organized authentic, high-resolution landmark images partitioned into Train (70%), Validation (15%), and Test (15%) splits.
2. **Stage 2 – Preprocessing & Augmentation**: Automated integrity sanitization (catching zero-byte or corrupt files), bilinear image resizing to $224 \times 224 \times 3$, normalization to $[-1, 1]$, and real-time spatial augmentations.
3. **Stage 3 – Transfer Learning Model Development**: Leveraged MobileNetV2 pre-trained on ImageNet with a custom classification head featuring GlobalAveragePooling2D, Batch Normalization, Dense(256) with $L_2$ regularization, and Dropout(0.35).
4. **Stage 4 – Model Evaluation**: Achieved **81.25% Test Accuracy**, **84.58% Macro Precision**, and **80.73% F1-Score**. Generated confusion matrix heatmaps and training/validation learning curves.
5. **Stage 5 – Interactive Streamlit Web Application**: Multi-tab graphical interface featuring image uploads, real-time inference, candidate probability distributions, interactive geographic maps, and historical dossiers.
6. **Stage 6 – Robust Edge-Case & Threshold Testing**: Rejection of non-landmark scenes using configurable confidence thresholds ($< 65\%$ categorized as *Unknown Landmark*) and safe exception handling for corrupt files.

---

## 🏛️ Supported Landmark Categories

| Landmark Class | Location | Architectural Style | Built Year | Coordinates |
| :--- | :--- | :--- | :--- | :--- |
| **Eiffel Tower** | Paris, France | Wrought-Iron Lattice | 1889 | 48.8584° N, 2.2945° E |
| **Taj Mahal** | Agra, India | Mughal Indo-Islamic | 1648 | 27.1751° N, 78.0421° E |
| **Colosseum** | Rome, Italy | Imperial Roman Classical | 80 AD | 41.8902° N, 12.4922° E |
| **Statue of Liberty** | New York, USA | Neoclassical Copper Repoussé | 1886 | 40.6892° N, -74.0445° W |
| **Great Wall of China** | Huairou / Beijing, China | Ancient Military Fortification | 14th C. | 40.4319° N, 116.5704° E |
| **Big Ben & Elizabeth Tower** | London, UK | Gothic Revival | 1859 | 51.5007° N, -0.1246° W |
| **Pyramids of Giza** | Giza / Cairo, Egypt | Ancient Egyptian Monumental | c. 2560 BC | 29.9792° N, 31.1342° E |
| **Sydney Opera House** | Sydney, Australia | Modernist Expressionism | 1973 | -33.8568° S, 151.2153° E |

---

## 🏗️ Project Architecture & Directory Structure

```text
street landmark navigater/
├── dataset/
│   ├── train/                      # Training split (15 images/class)
│   ├── val/                        # Validation split (3 images/class)
│   ├── test/                       # Test split (4 images/class)
│   ├── sample_tests/               # Demonstration test cases
│   │   ├── known/                  # Sample test images for all 8 landmarks
│   │   ├── unknown/                # Non-landmark scenes (bus, cat, desk, forest)
│   │   └── corrupted/              # Truncated and corrupt byte payloads
│   └── dataset_summary.json        # Dataset partition manifest
├── models/
│   ├── landmark_mobilenetv2_best.keras # Optimal checkpoint weights
│   ├── landmark_mobilenetv2.keras      # Final model artifact
│   ├── class_labels.json               # Class index to label mapping
│   ├── training_history.json           # Epoch-by-epoch loss & accuracy logs
│   └── model_summary.txt               # Architectural parameters and layer hierarchy
├── notebooks/
│   └── landmark_recognition_pipeline.ipynb # Step-by-step Jupyter demonstration
├── outputs/
│   ├── confusion_matrix.png            # Confusion matrix heatmap
│   ├── training_curves.png             # Train vs. Val Loss and Accuracy curves
│   ├── classification_report.txt       # Per-class precision, recall, and F1
│   ├── metrics_summary.json            # Machine-readable performance metrics
│   └── unseen_test_results.json        # Edge-case evaluation results
├── src/
│   ├── __init__.py
│   ├── utils.py                        # Geographical dossier database & validator
│   ├── preprocess.py                   # Resizing, MobileNet scaling, data augmentation
│   ├── data_loader.py                  # High-performance tf.data pipelines
│   ├── model.py                        # MobileNetV2 architecture definition
│   ├── train.py                        # Training execution script
│   ├── evaluate.py                     # Evaluation & diagnostic plotting script
│   ├── download_dataset.py             # Dataset scraper and split generator
│   ├── create_notebook.py              # Jupyter notebook generator
│   ├── test_app.py                     # Streamlit endpoint validation test
│   └── test_system.py                  # Stage 6 comprehensive test suite
├── app/
│   └── app.py                          # Full-Stack Streamlit Web Application
├── requirements.txt                    # Project dependencies
├── PROJECT_REPORT_GUVI.md              # Capstone Technical Review Documentation
└── README.md                           # Documentation & execution instructions
```

---

## ⚙️ Installation & Local Setup

### 1. Prerequisites
- Python 3.10 – 3.13 installed on Windows, macOS, or Linux.
- Git (optional).

### 2. Clone or Navigate to Project Directory
```powershell
cd "c:\Users\sures\Documents\street landmark navigater"
```

### 3. Create and Activate Virtual Environment (Recommended)
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 4. Install Dependencies
```powershell
pip install -r requirements.txt
```

---

## 🚀 Execution Guide

### Step 1: Dataset Preparation (Optional if already populated)
To re-download and sanitize images from Wikimedia Commons:
```powershell
python src/download_dataset.py
```

### Step 2: Model Training
Train the MobileNetV2 model using the curated dataset:
```powershell
python src/train.py --epochs 15 --batch_size 16 --lr 0.0003
```
*Note: Training automatically applies Early Stopping, Model Checkpointing, and saves the best model to `models/landmark_mobilenetv2_best.keras`.*

### Step 3: Run Quantitative Evaluation
Evaluate the model on unseen test sets and generate charts:
```powershell
python src/evaluate.py
```
Outputs generated in `outputs/`:
- `confusion_matrix.png`
- `training_curves.png`
- `classification_report.txt`

### Step 4: Execute Unit & Edge Case Test Suite
Run the 5-part verification suite covering preprocessing, known landmarks, unknown thresholds, and corruption resilience:
```powershell
python src/test_system.py
```

### Step 5: Launch the Streamlit Web Application
Launch the interactive web portal:
```powershell
streamlit run app/app.py
```
Open your browser and navigate to: **`http://localhost:8501`**.

---

## 📊 Model Evaluation Results

Evaluated on the independent test split (32 unseen samples):

```text
-------------------------------------------------------
Test Accuracy:           81.25%
Macro Precision:         84.58%
Macro Recall:            81.25%
Macro F1-Score:          80.73%
Weighted F1-Score:       80.73%
-------------------------------------------------------

Detailed Breakdown:
                      precision    recall  f1-score   support

            Big Ben       0.80      1.00      0.89         4
          Colosseum       1.00      0.75      0.86         4
       Eiffel Tower       0.75      0.75      0.75         4
Great Wall Of China       0.67      1.00      0.80         4
   Pyramids Of Giza       0.75      0.75      0.75         4
  Statue Of Liberty       0.80      1.00      0.89         4
 Sydney Opera House       1.00      0.50      0.67         4
          Taj Mahal       1.00      0.75      0.86         4

           accuracy                           0.81        32
          macro avg       0.85      0.81      0.81        32
       weighted avg       0.85      0.81      0.81        32
```

---

## 🌟 Key Application Features

1. **Intelligent Landmark Recognition**: Upload an image or select from sample test cases to identify structures with sub-50ms latency.
2. **Confidence Thresholding**: Filters non-landmark photos (pets, office desks, random vehicles). Items with $<65\%$ confidence are classified as *Unknown Landmark*.
3. **Data Integrity Guardian**: Invalid byte payloads, truncated JPEGs, and zero-byte files are intercepted before entering the model tensor flow.
4. **Interactive Geospatial Mapping**: Automatically plots landmark coordinates on interactive street maps (`st.map`).
5. **Architectural & Historical Dossier**: Displays constructor details, completion date, height, architectural style, and historical trivia.
6. **Street View 360° Panorama Direct Link**: Direct one-click exploration linking coordinates directly to Google Street View.
7. **Model Analytics Dashboard**: Built-in tab displaying real-time training curves, confusion matrix, and classification metrics.

---

## 📜 Academic & Industrial Relevance (GUVI Review)

This project satisfies all requirements for the GUVI AI/ML Capstone Project:
- **No fake predictions**: Powered by a genuinely trained TensorFlow/Keras deep learning model.
- **No hardcoded logic**: Softmax probability vectors determine all classifications.
- **Real-world robustness**: Edge cases (corrupt inputs, unlisted locations) are handled gracefully.
- **Clean modular design**: Clear separation of data loading, preprocessing, modeling, evaluation, and interface layers.
