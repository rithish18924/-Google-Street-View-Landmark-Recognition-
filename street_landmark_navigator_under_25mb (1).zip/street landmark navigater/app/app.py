"""
Google Street View – Landmark Recognition
Streamlit Web Application
An interactive AI/ML application powered by MobileNetV2 Transfer Learning,
recognizing global landmarks, providing rich geographical dossiers, and handling edge cases.
"""

import os
import sys
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image

# Setup workspace environment to ensure local .keras directory
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.append(str(WORKSPACE_ROOT))
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import streamlit as st
import tensorflow as tf
from src.preprocess import preprocess_pil_image, IMG_SIZE
from src.utils import get_landmark_info, validate_and_open_image, LANDMARK_INFO

# Page configuration
st.set_page_config(
    page_title="Google Street View – Landmark Recognition",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (CSS)
st.markdown("""
<style>
    /* Main container styling */
    .main-header {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        padding: 24px 30px;
        border-radius: 12px;
        color: white;
        margin-bottom: 25px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .main-header h1 {
        color: white;
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 8px;
    }
    .main-header p {
        color: #e0e6ed;
        font-size: 1.05rem;
        margin: 0;
    }
    
    /* Result Cards */
    .metric-card {
        background: #f8fafc;
        border-radius: 10px;
        padding: 16px;
        border: 1px solid #e2e8f0;
        margin-bottom: 15px;
    }
    .landmark-success-box {
        background: #ecfdf5;
        border-left: 6px solid #10b981;
        padding: 18px 22px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .landmark-unknown-box {
        background: #fffbeb;
        border-left: 6px solid #f59e0b;
        padding: 18px 22px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .landmark-error-box {
        background: #fef2f2;
        border-left: 6px solid #ef4444;
        padding: 18px 22px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .stat-pill {
        display: inline-block;
        background: #e2e8f0;
        color: #1e293b;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 0.85rem;
        font-weight: 600;
        margin-right: 6px;
        margin-bottom: 6px;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource(show_spinner=False)
def load_recognition_model():
    """Loads the trained MobileNetV2 model and class mapping dictionary."""
    models_dir = WORKSPACE_ROOT / "models"
    best_path = models_dir / "landmark_mobilenetv2_best.keras"
    final_path = models_dir / "landmark_mobilenetv2.keras"
    labels_path = models_dir / "class_labels.json"

    model_path = best_path if best_path.exists() else final_path

    if not model_path.exists():
        return None, None, f"Model artifact not found at {model_path}. Please train the model first."
    
    if not labels_path.exists():
        return None, None, f"Class labels not found at {labels_path}."

    try:
        model = tf.keras.models.load_model(str(model_path))
        with open(labels_path, "r", encoding="utf-8") as f:
            label_map = json.load(f)
        class_names = [label_map[str(i)] for i in range(len(label_map))]
        return model, class_names, None
    except Exception as exc:
        return None, None, f"Error loading model: {str(exc)}"


def predict_landmark(image: Image.Image, model, class_names: list[str], threshold: float = 0.65):
    """
    Runs model inference on PIL image, extracts top predictions,
    and applies confidence thresholding for unknown recognition.
    """
    # Preprocess image for MobileNetV2
    tensor = preprocess_pil_image(image, target_size=IMG_SIZE)
    probs = model.predict(tensor, verbose=0)[0]
    
    # Sort predictions
    sorted_indices = np.argsort(probs)[::-1]
    top_index = int(sorted_indices[0])
    top_prob = float(probs[top_index])
    top_label = class_names[top_index]

    top_3 = []
    for i in range(min(3, len(class_names))):
        idx = int(sorted_indices[i])
        top_3.append({
            "class": class_names[idx],
            "label": class_names[idx].replace("_", " ").title(),
            "confidence": float(probs[idx])
        })

    is_known = top_prob >= threshold

    return {
        "is_known": is_known,
        "predicted_label": top_label if is_known else "Unknown Landmark",
        "raw_label": top_label,
        "confidence": top_prob,
        "threshold": threshold,
        "top_3": top_3,
        "probabilities": probs
    }


def main():
    # Header Banner
    st.markdown("""
    <div class="main-header">
        <h1>🌍 Google Street View – Landmark Recognition</h1>
        <p>End-to-End Deep Learning System for Autonomous Landmark Identification, Geospatial Mapping & Knowledge Retrieval</p>
    </div>
    """, unsafe_allow_html=True)

    # Sidebar
    st.sidebar.title("⚙️ Control Panel")
    
    # Model Loading
    model, class_names, err_msg = load_recognition_model()
    if err_msg:
        st.sidebar.error("⚠️ " + err_msg)
    else:
        st.sidebar.success(f"✅ Model Loaded: MobileNetV2 ({len(class_names)} Classes)")

    # Threshold slider
    st.sidebar.markdown("---")
    st.sidebar.subheader("🎯 Recognition Parameters")
    confidence_threshold = st.sidebar.slider(
        "Confidence Threshold (%)",
        min_value=40,
        max_value=95,
        value=65,
        step=5,
        help="Predictions below this confidence percentage will be classified as 'Unknown Landmark' to reject non-landmark photos or uncertain locations."
    ) / 100.0

    st.sidebar.markdown("---")
    st.sidebar.subheader("🧪 Quick Test Samples")
    sample_category = st.sidebar.selectbox(
        "Select Test Scenario:",
        ["None (Upload Your Own)", "Known Landmarks", "Unknown / Non-Landmark Scenes", "Corrupted / Invalid Files"]
    )

    selected_sample_file = None
    if sample_category == "Known Landmarks":
        known_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "known"
        if known_dir.exists():
            files = [f.name for f in known_dir.iterdir() if f.is_file()]
            if files:
                choice = st.sidebar.selectbox("Choose Landmark Demo:", files)
                selected_sample_file = known_dir / choice
    elif sample_category == "Unknown / Non-Landmark Scenes":
        unknown_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "unknown"
        if unknown_dir.exists():
            files = [f.name for f in unknown_dir.iterdir() if f.is_file()]
            if files:
                choice = st.sidebar.selectbox("Choose Unknown Scene:", files)
                selected_sample_file = unknown_dir / choice
    elif sample_category == "Corrupted / Invalid Files":
        corrupt_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "corrupted"
        if corrupt_dir.exists():
            files = [f.name for f in corrupt_dir.iterdir() if f.is_file()]
            if files:
                choice = st.sidebar.selectbox("Choose Corrupted File:", files)
                selected_sample_file = corrupt_dir / choice

    # Navigation Tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Landmark Recognition",
        "🗺️ Street View Explorer",
        "📊 Model Evaluation & Metrics",
        "📖 Project Documentation (GUVI)"
    ])

    # -------------------------------------------------------------
    # TAB 1: LANDMARK RECOGNITION
    # -------------------------------------------------------------
    with tab1:
        col_input, col_result = st.columns([1, 1], gap="large")

        with col_input:
            st.subheader("1. Input Image Selection")
            uploaded_file = st.file_uploader(
                "Upload Street View image or photograph:",
                type=["jpg", "jpeg", "png", "webp", "bmp"],
                help="Supports JPEG, PNG, WEBP, and BMP formats."
            )

            # Determine image source
            active_image = None
            validation_error = None

            if uploaded_file is not None:
                pil_img, val_msg = validate_and_open_image(uploaded_file)
                if pil_img is None:
                    validation_error = val_msg
                else:
                    active_image = pil_img
            elif selected_sample_file is not None:
                st.info(f"Loaded sample file: `{selected_sample_file.name}`")
                pil_img, val_msg = validate_and_open_image(selected_sample_file)
                if pil_img is None:
                    validation_error = val_msg
                else:
                    active_image = pil_img

            # Display image preview
            if active_image is not None:
                st.image(active_image, caption="Image Preview", use_container_width=True)
                w, h = active_image.size
                st.caption(f"📐 Dimensions: {w} × {h} px | Format: {active_image.format or 'RGB'}")
            elif validation_error is not None:
                st.markdown(f"""
                <div class="landmark-error-box">
                    <h4 style="color: #991b1b; margin-top: 0;">❌ Corrupted or Invalid Image Detected</h4>
                    <p style="margin: 0; color: #7f1d1d;"><strong>Diagnostic:</strong> {validation_error}</p>
                    <p style="margin-top: 6px; font-size: 0.85rem; color: #991b1b;">The preprocessing pipeline verified the byte stream and rejected this file before it could cause runtime failures.</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.info("👆 Please upload an image or select a sample from the sidebar to begin recognition.")

            # Action button
            predict_btn = st.button("🚀 Identify Landmark", type="primary", use_container_width=True, disabled=(active_image is None or model is None))

        with col_result:
            st.subheader("2. Recognition Analysis")

            if predict_btn and active_image is not None and model is not None:
                with st.spinner("Analyzing architectural features via MobileNetV2 CNN..."):
                    time.sleep(0.15)
                    result = predict_landmark(active_image, model, class_names, threshold=confidence_threshold)

                conf_pct = result["confidence"] * 100

                if result["is_known"]:
                    landmark_key = result["raw_label"]
                    info = get_landmark_info(landmark_key)

                    st.markdown(f"""
                    <div class="landmark-success-box">
                        <div style="font-size: 0.9rem; color: #065f46; font-weight: 700; text-transform: uppercase;">
                            ✨ Landmark Recognized
                        </div>
                        <h2 style="color: #064e3b; margin: 4px 0 10px 0;">{info['name']}</h2>
                        <div style="margin-bottom: 10px;">
                            <span class="stat-pill">📍 {info['city']}, {info['country']}</span>
                            <span class="stat-pill">🏛️ {info['style']}</span>
                            <span class="stat-pill">📅 Completed: {info['completed_year']}</span>
                        </div>
                        <h4 style="color: #047857; margin: 8px 0 4px 0;">Prediction Confidence: {conf_pct:.2f}%</h4>
                    </div>
                    """, unsafe_allow_html=True)
                    st.progress(result["confidence"])

                    # Top-3 predictions
                    st.markdown("##### 🏆 Candidate Probabilities")
                    for cand in result["top_3"]:
                        col_c1, col_c2 = st.columns([3, 1])
                        with col_c1:
                            st.write(f"**{cand['label']}**")
                            st.progress(cand["confidence"])
                        with col_c2:
                            st.write(f"`{cand['confidence'] * 100:.2f}%`")

                    # Geographical Map
                    st.markdown("##### 📍 Geospatial Location")
                    map_df = pd.DataFrame([{
                        "lat": info["latitude"],
                        "lon": info["longitude"]
                    }])
                    st.map(map_df, zoom=13)

                    # Landmark Dossier
                    st.markdown("##### 📜 Architectural & Historical Dossier")
                    st.write(info["summary"])
                    st.info(f"💡 **Did you know?** {info['trivia']}")

                    # Google Street View Link
                    maps_search_url = f"https://www.google.com/maps/search/?api=1&query={info['latitude']},{info['longitude']}"
                    st.link_button(f"🌐 Explore {info['name']} on Google Street View & 360° Panorama", maps_search_url)

                else:
                    # Unknown Landmark outcome
                    st.markdown(f"""
                    <div class="landmark-unknown-box">
                        <div style="font-size: 0.9rem; color: #92400e; font-weight: 700; text-transform: uppercase;">
                            ⚠️ Unknown Landmark / Low Confidence
                        </div>
                        <h2 style="color: #78350f; margin: 4px 0 10px 0;">Unrecognized Location</h2>
                        <p style="color: #92400e; margin: 0;">The highest candidate model confidence was <strong>{conf_pct:.2f}%</strong>, which is below the configured threshold of <strong>{confidence_threshold * 100:.0f}%</strong>.</p>
                        <p style="margin-top: 6px; font-size: 0.85rem; color: #b45309;">This image may depict an unindexed location, a domestic scene, nature, or a non-monument subject.</p>
                    </div>
                    """, unsafe_allow_html=True)

                    st.markdown("##### 🔬 Model Top Candidate Log")
                    for cand in result["top_3"]:
                        st.write(f"- **{cand['label']}**: `{cand['confidence'] * 100:.2f}%`")
            elif not predict_btn and active_image is not None:
                st.info("Click **Identify Landmark** to process the image through the convolutional neural network.")
            elif active_image is None:
                st.write("Awaiting image input...")

    # -------------------------------------------------------------
    # TAB 2: STREET VIEW EXPLORER
    # -------------------------------------------------------------
    with tab2:
        st.subheader("🗺️ Global Landmark Coordinates & Street View Navigator")
        st.write("Explore the geographic coordinates, architectural metadata, and satellite footprints of supported landmarks.")

        selected_landmark = st.selectbox(
            "Select a landmark to explore:",
            options=list(LANDMARK_INFO.keys()),
            format_func=lambda k: f"{LANDMARK_INFO[k]['name']} ({LANDMARK_INFO[k]['city']}, {LANDMARK_INFO[k]['country']})"
        )

        landmark_data = LANDMARK_INFO[selected_landmark]
        col_info1, col_info2 = st.columns([1, 1], gap="medium")

        with col_info1:
            st.markdown(f"### {landmark_data['name']}")
            st.markdown(f"*{landmark_data.get('native_name', '')}*")
            st.write(landmark_data["summary"])
            
            st.markdown("#### 🏛️ Architectural Specifications")
            specs_df = pd.DataFrame([
                {"Property": "City & Country", "Detail": f"{landmark_data['city']}, {landmark_data['country']}"},
                {"Property": "Continent", "Detail": landmark_data["continent"]},
                {"Property": "Architectural Style", "Detail": landmark_data["style"]},
                {"Property": "Completed Year", "Detail": landmark_data["completed_year"]},
                {"Property": "Architect / Builder", "Detail": landmark_data["architect"]},
                {"Property": "Height", "Detail": f"{landmark_data['height_m']} meters"},
                {"Property": "Latitude", "Detail": f"{landmark_data['latitude']}°"},
                {"Property": "Longitude", "Detail": f"{landmark_data['longitude']}°"},
            ])
            st.table(specs_df)

            st.markdown(f"💡 **Historical Trivia:** {landmark_data['trivia']}")

        with col_info2:
            st.markdown("#### 🛰️ Geospatial Mapping")
            df_loc = pd.DataFrame([{"lat": landmark_data["latitude"], "lon": landmark_data["longitude"]}])
            st.map(df_loc, zoom=14)

            maps_direct = f"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint={landmark_data['latitude']},{landmark_data['longitude']}"
            st.link_button(f"🚀 Open Street View 360° for {landmark_data['name']}", maps_direct, use_container_width=True)

    # -------------------------------------------------------------
    # TAB 3: MODEL EVALUATION & METRICS
    # -------------------------------------------------------------
    with tab3:
        st.subheader("📊 Model Evaluation & Diagnostic Visualizations")
        st.write("Quantitative and visual performance metrics evaluated on the test dataset.")

        outputs_dir = WORKSPACE_ROOT / "outputs"
        metrics_file = outputs_dir / "metrics_summary.json"
        cm_image_path = outputs_dir / "confusion_matrix.png"
        curves_image_path = outputs_dir / "training_curves.png"
        report_file = outputs_dir / "classification_report.txt"

        if metrics_file.exists():
            with open(metrics_file, "r", encoding="utf-8") as f:
                metrics = json.load(f)

            m_col1, m_col2, m_col3, m_col4 = st.columns(4)
            with m_col1:
                st.metric("Test Accuracy", f"{metrics['test_accuracy'] * 100:.2f}%")
            with m_col2:
                st.metric("Macro Precision", f"{metrics['macro_precision'] * 100:.2f}%")
            with m_col3:
                st.metric("Macro Recall", f"{metrics['macro_recall'] * 100:.2f}%")
            with m_col4:
                st.metric("Macro F1-Score", f"{metrics['macro_f1_score'] * 100:.2f}%")

        col_g1, col_g2 = st.columns(2)
        with col_g1:
            if curves_image_path.exists():
                st.image(str(curves_image_path), caption="Training & Validation Learning Curves", use_container_width=True)
            else:
                st.info("Training curves will appear here once Stage 4 evaluation is executed.")

        with col_g2:
            if cm_image_path.exists():
                st.image(str(cm_image_path), caption="Confusion Matrix Heatmap", use_container_width=True)
            else:
                st.info("Confusion matrix will appear here once Stage 4 evaluation is executed.")

        if report_file.exists():
            st.markdown("#### 📋 Detailed Classification Report")
            with open(report_file, "r", encoding="utf-8") as f:
                st.code(f.read(), language="text")

    # -------------------------------------------------------------
    # TAB 4: PROJECT DOCUMENTATION (GUVI REVIEW)
    # -------------------------------------------------------------
    with tab4:
        st.subheader("📖 Project Technical Report (GUVI Capstone Review)")
        st.markdown("""
        ### 1. Executive Summary
        **Google Street View – Landmark Recognition** is an end-to-end artificial intelligence application designed to accurately identify global architectural landmarks from street-level panoramas and user photographs. The system integrates deep transfer learning with MobileNetV2, an intelligent preprocessing and data augmentation pipeline, automated image sanitization, geospatial metadata synthesis, and an interactive Streamlit UI.

        ---

        ### 2. Six-Stage Engineering Architecture
        ```
        [Stage 1: Dataset Collection]
                 │ (8 Landmark Classes + Unknowns + Corrupt Samples)
                 ▼
        [Stage 2: Preprocessing & Augmentation]
                 │ (Resizing 224x224, Normalization [-1, 1], Data Augmentation)
                 ▼
        [Stage 3: MobileNetV2 Transfer Learning]
                 │ (Pre-trained Feature Extractor + Custom Dense/Dropout Head)
                 ▼
        [Stage 4: Evaluation & Diagnostics]
                 │ (Accuracy, F1-Score, Confusion Matrix, Learning Curves)
                 ▼
        [Stage 5: Full-Stack Streamlit App]
                 │ (Image Upload, Preview, Inference, Top-3, Geospatial Dossier)
                 ▼
        [Stage 6: Edge Case & Threshold Testing]
                   (Unknown Landmark Filtering, Corruption Rejection, Street View Links)
        ```

        ---

        ### 3. Transfer Learning Rationale: Why MobileNetV2?
        1. **Inverted Residual Blocks & Linear Bottlenecks**: MobileNetV2 delivers state-of-the-art feature extraction capability with only ~2.2M parameters, making it exceptionally lightweight and fast for real-time web deployment.
        2. **ImageNet Pre-trained Weights**: The network has already learned low-level visual representations (edges, curves, textures, geometric shapes) on 1.4 million images, enabling high classification accuracy on custom landmarks even with moderate dataset sizes.
        3. **Low Latency**: Inference executes in under 50ms per frame on CPU, ensuring responsive user experience without requiring expensive GPU servers.

        ---

        ### 4. Edge Case Handling Strategy
        - **Corrupted Image Sanitization**: The PIL and OpenCV integrity checker validates binary stream headers and pixel dimensions before batch processing, safeguarding against zero-byte files, truncated payloads, and non-image data.
        - **Unknown Landmark Decision Boundary**: A softmax probability threshold (default 65%) prevents overconfident false-positive classifications on unseen natural scenes or non-monument objects.
        """)


if __name__ == "__main__":
    main()
