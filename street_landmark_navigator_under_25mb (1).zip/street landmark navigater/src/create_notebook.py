"""
Generates an interactive, step-by-step Jupyter Notebook for the project.
notebooks/landmark_recognition_pipeline.ipynb
"""

import json
from pathlib import Path


def create_pipeline_notebook(output_path: str = "notebooks/landmark_recognition_pipeline.ipynb"):
    cells = [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# Google Street View – Landmark Recognition\n",
                "### End-to-End Deep Learning Pipeline with MobileNetV2 Transfer Learning\n",
                "---\n",
                "This notebook guides through all 6 stages of the engineering workflow:\n",
                "1. **Stage 1**: Dataset Collection & Exploration\n",
                "2. **Stage 2**: Image Preprocessing, Data Augmentation & Sanitization\n",
                "3. **Stage 3**: MobileNetV2 Architecture & Transfer Learning\n",
                "4. **Stage 4**: Model Training & Learning Dynamics\n",
                "5. **Stage 5**: Performance Evaluation, Confusion Matrix & Metrics\n",
                "6. **Stage 6**: Unseen Image Testing & Unknown Decision Thresholding"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "import os\n",
                "import sys\n",
                "import json\n",
                "from pathlib import Path\n",
                "import numpy as np\n",
                "import pandas as pd\n",
                "import matplotlib.pyplot as plt\n",
                "import seaborn as sns\n",
                "from PIL import Image\n",
                "\n",
                "# Ensure project root in python path\n",
                "PROJECT_ROOT = Path('.').resolve().parent if Path('.').resolve().name == 'notebooks' else Path('.').resolve()\n",
                "sys.path.append(str(PROJECT_ROOT))\n",
                "os.environ['KERAS_HOME'] = str(PROJECT_ROOT / '.keras')\n",
                "os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'\n",
                "\n",
                "import tensorflow as tf\n",
                "print(f'TensorFlow Version: {tf.__version__}')\n",
                "print(f'GPU Available: {len(tf.config.list_physical_devices(\"GPU\")) > 0}')"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Stage 1: Dataset Summary & Class Distribution\n",
                "Let's inspect the dataset directory structure and counts across training, validation, and test splits."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "dataset_dir = PROJECT_ROOT / 'dataset'\n",
                "summary_file = dataset_dir / 'dataset_summary.json'\n",
                "\n",
                "if summary_file.exists():\n",
                "    with open(summary_file, 'r') as f:\n",
                "        summary_data = json.load(f)\n",
                "    df_summary = pd.DataFrame(summary_data).T\n",
                "    display(df_summary)\n",
                "    \n",
                "    # Plot distribution\n",
                "    df_summary[['train', 'val', 'test']].plot(kind='bar', stacked=True, figsize=(10, 5), colormap='viridis')\n",
                "    plt.title('Dataset Split Distribution by Landmark Class')\n",
                "    plt.xlabel('Landmark')\n",
                "    plt.ylabel('Image Count')\n",
                "    plt.xticks(rotation=45, ha='right')\n",
                "    plt.tight_layout()\n",
                "    plt.show()"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Stage 2: Data Preprocessing & Augmentation Pipeline\n",
                "We test the data augmentation layers to verify that images undergo random rotation, zoom, flip, and contrast adjustment."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from src.preprocess import get_data_augmentation_layers\n",
                "\n",
                "aug_layer = get_data_augmentation_layers()\n",
                "\n",
                "# Pick a sample image\n",
                "sample_known = list((PROJECT_ROOT / 'dataset' / 'sample_tests' / 'known').glob('*.jpg'))\n",
                "if sample_known:\n",
                "    img = Image.open(sample_known[0]).convert('RGB').resize((224, 224))\n",
                "    img_tensor = tf.expand_dims(np.array(img), 0)\n",
                "    \n",
                "    fig, axes = plt.subplots(1, 5, figsize=(15, 3))\n",
                "    axes[0].imshow(img)\n",
                "    axes[0].set_title('Original')\n",
                "    axes[0].axis('off')\n",
                "    \n",
                "    for i in range(1, 5):\n",
                "        augmented = aug_layer(img_tensor, training=True)\n",
                "        axes[i].imshow(tf.cast(augmented[0], tf.uint8))\n",
                "        axes[i].set_title(f'Augmented #{i}')\n",
                "        axes[i].axis('off')\n",
                "    plt.tight_layout()\n",
                "    plt.show()"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Stage 3 & 4: Model Architecture & Evaluation Results\n",
                "We load the trained MobileNetV2 model and display the evaluation metrics."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from src.model import build_landmark_classifier\n",
                "\n",
                "# Load metrics\n",
                "metrics_file = PROJECT_ROOT / 'outputs' / 'metrics_summary.json'\n",
                "if metrics_file.exists():\n",
                "    with open(metrics_file, 'r') as f:\n",
                "        metrics = json.load(f)\n",
                "    print('Test Evaluation Metrics:')\n",
                "    for k, v in metrics.items():\n",
                "        print(f' - {k}: {v}')\n",
                "\n",
                "# Display Confusion Matrix\n",
                "cm_path = PROJECT_ROOT / 'outputs' / 'confusion_matrix.png'\n",
                "if cm_path.exists():\n",
                "    plt.figure(figsize=(10, 8))\n",
                "    plt.imshow(Image.open(cm_path))\n",
                "    plt.axis('off')\n",
                "    plt.title('Evaluated Confusion Matrix')\n",
                "    plt.show()\n",
                "\n",
                "# Display Training Curves\n",
                "tc_path = PROJECT_ROOT / 'outputs' / 'training_curves.png'\n",
                "if tc_path.exists():\n",
                "    plt.figure(figsize=(12, 5))\n",
                "    plt.imshow(Image.open(tc_path))\n",
                "    plt.axis('off')\n",
                "    plt.title('Training & Validation Curves')\n",
                "    plt.show()"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Stage 5 & 6: Inference & Confidence Thresholding\n",
                "Demonstrating model prediction on unseen samples and how the confidence threshold filters out non-landmark scenes."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from src.preprocess import preprocess_pil_image\n",
                "from src.utils import get_landmark_info\n",
                "\n",
                "model_path = PROJECT_ROOT / 'models' / 'landmark_mobilenetv2_best.keras'\n",
                "labels_path = PROJECT_ROOT / 'models' / 'class_labels.json'\n",
                "\n",
                "if model_path.exists() and labels_path.exists():\n",
                "    model = tf.keras.models.load_model(str(model_path))\n",
                "    with open(labels_path, 'r') as f:\n",
                "        label_map = json.load(f)\n",
                "    class_names = [label_map[str(i)] for i in range(len(label_map))]\n",
                "    \n",
                "    test_samples = list((PROJECT_ROOT / 'dataset' / 'sample_tests' / 'known').glob('*.jpg'))[:2] + \\\n",
                "                   list((PROJECT_ROOT / 'dataset' / 'sample_tests' / 'unknown').glob('*.jpg'))[:2]\n",
                "    \n",
                "    for img_path in test_samples:\n",
                "        img = Image.open(img_path)\n",
                "        tensor = preprocess_pil_image(img)\n",
                "        probs = model.predict(tensor, verbose=0)[0]\n",
                "        top_idx = int(np.argmax(probs))\n",
                "        conf = float(probs[top_idx])\n",
                "        \n",
                "        threshold = 0.65\n",
                "        is_known = conf >= threshold\n",
                "        pred_label = class_names[top_idx] if is_known else 'Unknown Landmark'\n",
                "        \n",
                "        print(f'File: {img_path.name:<25} -> Pred: {pred_label:<20} (Conf: {conf*100:.2f}%) | Flag: {\"KNOWN\" if is_known else \"UNKNOWN\"}')"
            ]
        }
    ]

    notebook_content = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "name": "python",
                "version": "3.13"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }

    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(notebook_content, f, indent=2)
    print(f"[*] Jupyter Notebook created at: {output_file}")


if __name__ == "__main__":
    create_pipeline_notebook()
