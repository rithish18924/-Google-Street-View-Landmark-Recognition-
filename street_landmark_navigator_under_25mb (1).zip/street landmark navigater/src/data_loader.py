"""
Stage 2 & 3: Data Loader Module
Loads training, validation, and testing datasets using TensorFlow tf.data pipelines.
Applies preprocessing, caching, prefetching, and extracts class index mappings.
"""

import os
import sys
import json
from pathlib import Path
from typing import Tuple, List

# Workspace local environment
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input as mobilenet_preprocess
from src.preprocess import get_data_augmentation_layers, IMG_SIZE


def create_data_pipeline(
    dataset_dir: str | Path = "dataset",
    batch_size: int = 16,
    img_size: Tuple[int, int] = IMG_SIZE,
    augment_training: bool = True
) -> Tuple[tf.data.Dataset, tf.data.Dataset, tf.data.Dataset, List[str]]:
    """
    Loads train, val, and test splits from the dataset directory and
    constructs high-performance tf.data pipelines with MobileNetV2 preprocessing.
    """
    dataset_dir = Path(dataset_dir)
    train_dir = dataset_dir / "train"
    val_dir = dataset_dir / "val"
    test_dir = dataset_dir / "test"

    if not train_dir.exists():
        raise FileNotFoundError(f"Training directory not found at {train_dir}")

    # Load raw image datasets with categorical labels
    train_ds = tf.keras.utils.image_dataset_from_directory(
        train_dir,
        label_mode="categorical",
        image_size=img_size,
        batch_size=batch_size,
        shuffle=True,
        seed=42
    )

    class_names = train_ds.class_names
    print(f"[*] Found {len(class_names)} landmark classes: {class_names}")

    val_ds = tf.keras.utils.image_dataset_from_directory(
        val_dir,
        label_mode="categorical",
        image_size=img_size,
        batch_size=batch_size,
        shuffle=False
    )

    test_ds = tf.keras.utils.image_dataset_from_directory(
        test_dir,
        label_mode="categorical",
        image_size=img_size,
        batch_size=batch_size,
        shuffle=False
    )

    # Preprocessing transformation: MobileNetV2 requires [-1, 1] scaling
    def preprocess_fn(images, labels):
        return mobilenet_preprocess(images), labels

    augmentation_layer = get_data_augmentation_layers()

    # Build optimized train pipeline with optional on-the-fly augmentation
    if augment_training:
        train_pipeline = (
            train_ds
            .map(lambda x, y: (augmentation_layer(x, training=True), y), num_parallel_calls=tf.data.AUTOTUNE)
            .map(preprocess_fn, num_parallel_calls=tf.data.AUTOTUNE)
            .cache()
            .prefetch(buffer_size=tf.data.AUTOTUNE)
        )
    else:
        train_pipeline = (
            train_ds
            .map(preprocess_fn, num_parallel_calls=tf.data.AUTOTUNE)
            .cache()
            .prefetch(buffer_size=tf.data.AUTOTUNE)
        )

    val_pipeline = (
        val_ds
        .map(preprocess_fn, num_parallel_calls=tf.data.AUTOTUNE)
        .cache()
        .prefetch(buffer_size=tf.data.AUTOTUNE)
    )

    test_pipeline = (
        test_ds
        .map(preprocess_fn, num_parallel_calls=tf.data.AUTOTUNE)
        .cache()
        .prefetch(buffer_size=tf.data.AUTOTUNE)
    )

    return train_pipeline, val_pipeline, test_pipeline, class_names


def save_class_mappings(class_names: List[str], output_path: str | Path = "models/class_labels.json"):
    """Serializes the class index to label dictionary."""
    mapping = {idx: name for idx, name in enumerate(class_names)}
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(mapping, f, indent=4)
    print(f"[*] Class label mapping saved to: {output_path}")
