"""
Dataset Collector for Google Street View – Landmark Recognition
Fetches authentic, high-resolution landmark images from Wikimedia Commons API
and partitions them into training, validation, and testing sets.
Also sets up benchmark unknown test images and invalid/corrupted image samples.
"""

import os
import sys
import json
import time
import shutil
import random
import urllib.request
import urllib.parse
from pathlib import Path
from PIL import Image

# Landmarks to fetch
LANDMARK_QUERIES = {
    "eiffel_tower": "Eiffel Tower Paris landmark",
    "taj_mahal": "Taj Mahal",
    "colosseum": "Colosseum Rome exterior architecture",
    "statue_of_liberty": "Statue of Liberty New York monument",
    "great_wall_of_china": "Great Wall of China landscape",
    "big_ben": "Big Ben London Elizabeth Tower",
    "pyramids_of_giza": "Great Pyramid of Giza Egypt",
    "sydney_opera_house": "Sydney Opera House harbor view"
}

# Non-landmark unknown categories for threshold testing
UNKNOWN_QUERIES = {
    "cat_pet": "Domestic cat portrait",
    "city_bus": "City transit bus street",
    "office_desk": "Modern computer office desk workspace",
    "forest_trees": "Green pine forest nature landscape"
}

HEADERS = {
    "User-Agent": "LandmarkRecognitionProject/1.0 (educational research at GUVI; mailto:student@example.org)"
}

DATASET_ROOT = Path("dataset")
TRAIN_DIR = DATASET_ROOT / "train"
VAL_DIR = DATASET_ROOT / "val"
TEST_DIR = DATASET_ROOT / "test"
SAMPLE_TESTS_DIR = DATASET_ROOT / "sample_tests"


def search_wikimedia_images(query: str, limit: int = 35) -> list[str]:
    """Search Wikimedia Commons for image URLs matching a query, using 500px CDN thumbnails."""
    base_url = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query",
        "generator": "search",
        "gsrsearch": query,
        "gsrnamespace": "6",  # File namespace
        "gsrlimit": str(limit),
        "prop": "imageinfo",
        "iiprop": "url|thumburl|mime|size",
        "iiurlwidth": "500",
        "format": "json"
    }
    url = f"{base_url}?{urllib.parse.urlencode(params)}"
    
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        print(f"[!] API search failed for '{query}': {exc}", flush=True)
        return []

    pages = data.get("query", {}).get("pages", {})
    image_urls = []

    for page_id, page in pages.items():
        imageinfo = page.get("imageinfo", [])
        if not imageinfo:
            continue
        info = imageinfo[0]
        # Prefer the 500px thumbnail url if available, otherwise fallback to url
        img_url = info.get("thumburl") or info.get("url", "")
        if img_url:
            # Exclude SVG, TIFF, audio/video or tiny icons
            if not any(ext in img_url.lower() for ext in [".svg", ".tif", ".pdf", ".ogg"]):
                image_urls.append(img_url)

    return image_urls


def is_valid_image(filepath: Path) -> bool:
    """Validate that image is not corrupted, is readable by PIL and OpenCV, and has valid dimensions."""
    try:
        with Image.open(filepath) as img:
            img.verify()  # Verify integrity
        with Image.open(filepath) as img:
            img = img.convert("RGB")
            w, h = img.size
            if w < 64 or h < 64:
                return False
        return True
    except Exception:
        return False


def download_file(url: str, dest_path: Path) -> bool:
    """Download a file with User-Agent and timeout."""
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=20) as resp, open(dest_path, "wb") as f:
            shutil.copyfileobj(resp, f)
        return True
    except Exception as e:
        return False


def collect_landmarks(target_per_class: int = 24):
    """Download authentic landmark images and distribute into train/val/test."""
    print("=" * 65)
    print("STAGE 1: AUTHENTIC LANDMARK DATASET COLLECTION")
    print("=" * 65)
    
    random.seed(42)
    os.makedirs(SAMPLE_TESTS_DIR / "known", exist_ok=True)
    os.makedirs(SAMPLE_TESTS_DIR / "unknown", exist_ok=True)
    os.makedirs(SAMPLE_TESTS_DIR / "corrupted", exist_ok=True)

    summary = {}

    for label, query in LANDMARK_QUERIES.items():
        print(f"\n[*] Sourcing images for category: '{label}' (Query: '{query}')...", flush=True)
        train_path = TRAIN_DIR / label
        val_path = VAL_DIR / label
        test_path = TEST_DIR / label

        os.makedirs(train_path, exist_ok=True)
        os.makedirs(val_path, exist_ok=True)
        os.makedirs(test_path, exist_ok=True)

        # Retrieve candidates
        urls = search_wikimedia_images(query, limit=target_per_class + 15)
        print(f"    Found {len(urls)} candidate URLs from Wikimedia Commons.", flush=True)

        valid_files = []
        temp_dir = Path("dataset") / "_temp" / label
        os.makedirs(temp_dir, exist_ok=True)

        for idx, url in enumerate(urls):
            if len(valid_files) >= target_per_class:
                break
            temp_file = temp_dir / f"img_{idx}.jpg"
            if download_file(url, temp_file):
                if is_valid_image(temp_file):
                    valid_files.append(temp_file)
                else:
                    if temp_file.exists():
                        temp_file.unlink()
            time.sleep(0.05)  # Fast respectful rate limit

        print(f"    Validated {len(valid_files)} clean images for '{label}'.", flush=True)
        random.shuffle(valid_files)

        # 70% Train, 15% Val, 15% Test
        n_total = len(valid_files)
        n_train = int(n_total * 0.70)
        n_val = int(n_total * 0.15)
        
        train_files = valid_files[:n_train]
        val_files = valid_files[n_train:n_train + n_val]
        test_files = valid_files[n_train + n_val:]

        for i, src in enumerate(train_files):
            shutil.copy(src, train_path / f"{label}_train_{i+1:03d}.jpg")
        for i, src in enumerate(val_files):
            shutil.copy(src, val_path / f"{label}_val_{i+1:03d}.jpg")
        for i, src in enumerate(test_files):
            shutil.copy(src, test_path / f"{label}_test_{i+1:03d}.jpg")
            # Also save one copy to sample_tests/known for quick UI demo testing
            if i == 0:
                shutil.copy(src, SAMPLE_TESTS_DIR / "known" / f"{label}_demo.jpg")

        # Cleanup temp directory
        shutil.rmtree(temp_dir, ignore_errors=True)

        summary[label] = {
            "train": len(train_files),
            "val": len(val_files),
            "test": len(test_files),
            "total": n_total
        }

    # Clean up parent temp directory if exists
    shutil.rmtree(Path("dataset") / "_temp", ignore_errors=True)

    # Now download unknown sample images for Stage 6 Unknown testing
    print("\n[*] Sourcing unknown benchmark images for threshold validation...")
    for label, query in UNKNOWN_QUERIES.items():
        urls = search_wikimedia_images(query, limit=5)
        for idx, url in enumerate(urls[:2]):
            temp_file = SAMPLE_TESTS_DIR / "unknown" / f"{label}_{idx+1}.jpg"
            if download_file(url, temp_file):
                if not is_valid_image(temp_file):
                    temp_file.unlink()
            time.sleep(0.3)

    # Create synthetic corrupted image samples for testing corrupted file handling
    print("[*] Generating corrupted/invalid image test cases...")
    corrupt_01 = SAMPLE_TESTS_DIR / "corrupted" / "corrupted_truncated.jpg"
    with open(corrupt_01, "wb") as f:
        f.write(b"\xff\xd8\xff\xe0\x00\x10JFIF" + b"\x00" * 30)  # Header with truncated body
    
    corrupt_02 = SAMPLE_TESTS_DIR / "corrupted" / "corrupted_random_noise.png"
    with open(corrupt_02, "wb") as f:
        f.write(b"NOT_A_VALID_IMAGE_FILE_DATA_CORRUPTED_BYTES")

    # Dataset metadata summary
    metadata_path = DATASET_ROOT / "dataset_summary.json"
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=4)

    print("\n" + "=" * 65)
    print("DATASET COLLECTION COMPLETE")
    print("=" * 65)
    print(f"Summary saved to: {metadata_path}")
    for k, v in summary.items():
        print(f" - {k:<22}: Train={v['train']}, Val={v['val']}, Test={v['test']} (Total: {v['total']})")


if __name__ == "__main__":
    collect_landmarks(target_per_class=22)
