"""
Stage 4: Model Evaluation Module
Calculates Accuracy, Precision, Recall, F1-Score, generates Confusion Matrix,
plots Training & Validation curves, and evaluates unseen/unknown test images.
"""

import os
import sys
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_fscore_support, accuracy_score

# Setup workspace root in path and local keras home
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from src.data_loader import create_data_pipeline
from src.preprocess import preprocess_pil_image
from src.utils import validate_and_open_image, get_landmark_info


def plot_training_curves(history_file: str | Path, output_path: str | Path):
    """Generates and saves side-by-side training vs validation loss and accuracy curves."""
    with open(history_file, "r", encoding="utf-8") as f:
        history = json.load(f)

    epochs = range(1, len(history.get("loss", [])) + 1)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Loss plot
    ax1.plot(epochs, history.get("loss", []), "o-", label="Train Loss", color="#e74c3c", lw=2)
    ax1.plot(epochs, history.get("val_loss", []), "s--", label="Val Loss", color="#c0392b", lw=2)
    ax1.set_title("Training & Validation Loss", fontsize=14, fontweight="bold", pad=10)
    ax1.set_xlabel("Epoch", fontsize=12)
    ax1.set_ylabel("Categorical Crossentropy", fontsize=12)
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax1.legend(fontsize=11)

    # Accuracy plot
    ax2.plot(epochs, [a * 100 for a in history.get("accuracy", [])], "o-", label="Train Accuracy", color="#2ecc71", lw=2)
    ax2.plot(epochs, [a * 100 for a in history.get("val_accuracy", [])], "s--", label="Val Accuracy", color="#27ae60", lw=2)
    ax2.set_title("Training & Validation Accuracy (%)", fontsize=14, fontweight="bold", pad=10)
    ax2.set_xlabel("Epoch", fontsize=12)
    ax2.set_ylabel("Accuracy (%)", fontsize=12)
    ax2.grid(True, linestyle="--", alpha=0.6)
    ax2.legend(fontsize=11)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"[*] Training curves saved to: {output_path}")


def plot_confusion_matrix(y_true, y_pred, class_names, output_path: str | Path):
    """Renders high-resolution confusion matrix heatmap with Seaborn."""
    cm = confusion_matrix(y_true, y_pred)
    display_labels = [name.replace("_", " ").title() for name in class_names]

    plt.figure(figsize=(10, 8))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=display_labels,
        yticklabels=display_labels,
        cbar=True,
        linewidths=1,
        linecolor="#bdc3c7"
    )
    plt.title("Google Street View – Landmark Recognition Confusion Matrix", fontsize=14, fontweight="bold", pad=15)
    plt.xlabel("Predicted Landmark", fontsize=12, labelpad=10)
    plt.ylabel("Ground Truth Landmark", fontsize=12, labelpad=10)
    plt.xticks(rotation=40, ha="right", fontsize=10)
    plt.yticks(rotation=0, fontsize=10)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"[*] Confusion matrix saved to: {output_path}")


def evaluate_model_performance(
    dataset_dir: str = "dataset",
    models_dir: str = "models",
    outputs_dir: str = "outputs",
    confidence_threshold: float = 0.60
):
    print("=" * 65)
    print("STAGE 4: COMPREHENSIVE MODEL EVALUATION")
    print("=" * 65)

    dataset_path = Path(dataset_dir)
    models_path = Path(models_dir)
    outputs_path = Path(outputs_dir)
    outputs_path.mkdir(parents=True, exist_ok=True)

    # 1. Load class labels
    labels_file = models_path / "class_labels.json"
    with open(labels_file, "r", encoding="utf-8") as f:
        label_map = json.load(f)
    class_names = [label_map[str(i)] for i in range(len(label_map))]

    # 2. Load best trained model
    best_model_file = models_path / "landmark_mobilenetv2_best.keras"
    if not best_model_file.exists():
        best_model_file = models_path / "landmark_mobilenetv2.keras"

    print(f"[*] Loading model from: {best_model_file}")
    model = tf.keras.models.load_model(str(best_model_file))

    # 3. Load test dataset
    _, _, test_ds, _ = create_data_pipeline(dataset_dir=dataset_path, batch_size=16, augment_training=False)

    # 4. Generate predictions on test dataset
    print("[*] Generating predictions on unseen test dataset...")
    y_true_list = []
    y_pred_list = []
    y_probs_list = []

    for batch_images, batch_labels in test_ds:
        preds = model.predict(batch_images, verbose=0)
        true_indices = np.argmax(batch_labels.numpy(), axis=1)
        pred_indices = np.argmax(preds, axis=1)

        y_true_list.extend(true_indices)
        y_pred_list.extend(pred_indices)
        y_probs_list.extend(preds)

    y_true = np.array(y_true_list)
    y_pred = np.array(y_pred_list)

    # 5. Compute Quantitative Metrics
    acc = accuracy_score(y_true, y_pred)
    prec_macro, rec_macro, f1_macro, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    prec_weight, rec_weight, f1_weight, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted", zero_division=0)

    report_str = classification_report(
        y_true,
        y_pred,
        target_names=[name.replace("_", " ").title() for name in class_names],
        zero_division=0
    )

    print("\n" + "-" * 55)
    print(f"Test Accuracy:           {acc * 100:.2f}%")
    print(f"Macro Precision:         {prec_macro * 100:.2f}%")
    print(f"Macro Recall:            {rec_macro * 100:.2f}%")
    print(f"Macro F1-Score:          {f1_macro * 100:.2f}%")
    print(f"Weighted F1-Score:       {f1_weight * 100:.2f}%")
    print("-" * 55)
    print("\nClassification Report:\n", report_str)

    # Save classification report
    with open(outputs_path / "classification_report.txt", "w", encoding="utf-8") as f:
        f.write(report_str)

    metrics_dict = {
        "test_accuracy": float(acc),
        "macro_precision": float(prec_macro),
        "macro_recall": float(rec_macro),
        "macro_f1_score": float(f1_macro),
        "weighted_f1_score": float(f1_weight),
        "total_test_samples": int(len(y_true)),
        "num_classes": len(class_names)
    }
    with open(outputs_path / "metrics_summary.json", "w", encoding="utf-8") as f:
        json.dump(metrics_dict, f, indent=4)

    # 6. Generate Visual Charts
    cm_path = outputs_path / "confusion_matrix.png"
    plot_confusion_matrix(y_true, y_pred, class_names, cm_path)

    history_file = models_path / "training_history.json"
    if history_file.exists():
        curves_path = outputs_path / "training_curves.png"
        plot_training_curves(history_file, curves_path)

    # 7. Evaluate Unknown & Corrupted Sample Test Images (Stage 6)
    print("\n[*] Evaluating Unknown & Corrupted Image Handling...")
    unknown_dir = dataset_path / "sample_tests" / "unknown"
    unknown_results = []
    
    if unknown_dir.exists():
        for test_file in unknown_dir.iterdir():
            if not test_file.is_file():
                continue
            pil_img, msg = validate_and_open_image(test_file)
            if pil_img is None:
                unknown_results.append({"file": test_file.name, "status": "Corrupted/Invalid", "detail": msg})
                continue
            
            img_tensor = preprocess_pil_image(pil_img)
            probs = model.predict(img_tensor, verbose=0)[0]
            max_idx = int(np.argmax(probs))
            conf = float(probs[max_idx])
            
            if conf < confidence_threshold:
                predicted_label = "Unknown Landmark"
                decision = "Flagged as Unknown (Below Threshold)"
            else:
                predicted_label = class_names[max_idx]
                decision = "High-confidence misclassification"

            unknown_results.append({
                "file": test_file.name,
                "confidence": round(conf * 100, 2),
                "predicted": predicted_label,
                "threshold_applied": confidence_threshold,
                "decision": decision
            })

    # Save unseen evaluation results
    with open(outputs_path / "unseen_test_results.json", "w", encoding="utf-8") as f:
        json.dump(unknown_results, f, indent=4)

    print(f"[*] Unknown test image evaluations saved: {len(unknown_results)} items tested.")
    print("\n" + "=" * 65)
    print("STAGE 4 EVALUATION COMPLETED")
    print("=" * 65)


if __name__ == "__main__":
    evaluate_model_performance()
