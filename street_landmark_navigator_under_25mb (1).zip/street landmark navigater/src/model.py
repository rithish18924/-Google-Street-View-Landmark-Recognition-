"""
Stage 3: Landmark Classification Model Architecture
Implements Transfer Learning with MobileNetV2 and custom classification head.
"""

import os
from pathlib import Path
from typing import Tuple

# Setup local keras home
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from tensorflow.keras import layers, models, regularizers
from tensorflow.keras.applications import MobileNetV2
from src.preprocess import IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS


def build_landmark_classifier(
    num_classes: int,
    input_shape: Tuple[int, int, int] = (IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS),
    learning_rate: float = 1e-4,
    freeze_base: bool = True,
    dropout_rate: float = 0.4
) -> tf.keras.Model:
    """
    Builds a Transfer Learning model using MobileNetV2 backbone.
    
    Architecture:
    1. Input layer (224, 224, 3)
    2. MobileNetV2 Feature Extractor (pre-trained on ImageNet)
    3. GlobalAveragePooling2D
    4. BatchNormalization
    5. Dense(256, relu) with L2 regularization
    6. Dropout(dropout_rate)
    7. Dense(num_classes, softmax) output
    """
    inputs = layers.Input(shape=input_shape, name="input_image")

    # MobileNetV2 pre-trained backbone
    base_model = MobileNetV2(
        input_shape=input_shape,
        include_top=False,
        weights="imagenet"
    )

    # Freeze base model layers initially for transfer learning stability
    base_model.trainable = not freeze_base
    if not freeze_base:
        # Fine-tune only the top layers (e.g. from layer 100 onwards)
        fine_tune_at = 100
        for layer in base_model.layers[:fine_tune_at]:
            layer.trainable = False

    x = base_model(inputs, training=False)
    x = layers.GlobalAveragePooling2D(name="global_avg_pool")(x)
    x = layers.BatchNormalization(name="batch_norm")(x)
    x = layers.Dense(
        256,
        activation="relu",
        kernel_regularizer=regularizers.l2(1e-4),
        name="dense_features"
    )(x)
    x = layers.Dropout(dropout_rate, name="dropout")(x)
    
    outputs = layers.Dense(num_classes, activation="softmax", name="landmark_prediction")(x)

    model = models.Model(inputs=inputs, outputs=outputs, name="Google_Street_View_Landmark_Classifier")

    # Compile with Adam optimizer, categorical crossentropy, and multi-metric tracking
    optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss="categorical_crossentropy",
        metrics=[
            "accuracy",
            tf.keras.metrics.Precision(name="precision"),
            tf.keras.metrics.Recall(name="recall")
        ]
    )

    return model


if __name__ == "__main__":
    print("[*] Testing model construction...")
    model = build_landmark_classifier(num_classes=8)
    model.summary()
