"""
Stage 2: Image Preprocessing and Augmentation Pipeline
Handles image resizing, normalization, data augmentation layers, and corrupted image sanitization.
"""

import os
import sys
from pathlib import Path
import numpy as np
import cv2
from PIL import Image

# Setup local keras home
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input as mobilenet_preprocess

# Target model dimensions
IMG_HEIGHT = 224
IMG_WIDTH = 224
IMG_CHANNELS = 3
IMG_SIZE = (IMG_HEIGHT, IMG_WIDTH)


def get_data_augmentation_layers() -> tf.keras.Sequential:
    """
    Constructs a Keras data augmentation pipeline.
    Applies random transformations during training to boost generalization.
    """
    augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.15),
        layers.RandomZoom(0.15),
        layers.RandomTranslation(height_factor=0.1, width_factor=0.1),
        layers.RandomContrast(0.15),
    ], name="data_augmentation")
    return augmentation


def sanitize_dataset_directory(data_dir: str | Path) -> dict:
    """
    Scans dataset directory, validates every image using PIL and OpenCV,
    and removes or quarantines corrupted/truncated files.
    """
    data_dir = Path(data_dir)
    stats = {"inspected": 0, "valid": 0, "corrupted": 0, "removed": []}
    
    if not data_dir.exists():
        return stats

    for class_folder in data_dir.iterdir():
        if not class_folder.is_dir():
            continue
        for img_file in class_folder.iterdir():
            if img_file.suffix.lower() not in [".jpg", ".jpeg", ".png", ".bmp", ".webp"]:
                continue
            stats["inspected"] += 1
            is_good = True
            
            # Test 1: Check non-zero size
            if img_file.stat().st_size < 128:
                is_good = False
            
            # Test 2: PIL verification
            if is_good:
                try:
                    with Image.open(img_file) as im:
                        im.verify()
                    with Image.open(img_file) as im:
                        im = im.convert("RGB")
                        if im.size[0] < 16 or im.size[1] < 16:
                            is_good = False
                except Exception:
                    is_good = False
            
            # Test 3: OpenCV decode check
            if is_good:
                try:
                    cv_img = cv2.imread(str(img_file))
                    if cv_img is None or cv_img.size == 0:
                        is_good = False
                except Exception:
                    is_good = False

            if is_good:
                stats["valid"] += 1
            else:
                stats["corrupted"] += 1
                stats["removed"].append(str(img_file))
                try:
                    img_file.unlink()
                except Exception:
                    pass

    return stats


def preprocess_numpy_image(img_array: np.ndarray, target_size: tuple[int, int] = IMG_SIZE) -> np.ndarray:
    """
    Preprocesses a raw BGR/RGB numpy image array for MobileNetV2 inference:
    1. Ensures RGB format
    2. Resizes to target_size (224, 224)
    3. Normalizes pixel values via mobilenet_preprocess
    4. Expands dimensions to (1, 224, 224, 3)
    """
    if len(img_array.shape) == 2:  # Grayscale
        img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2RGB)
    elif img_array.shape[2] == 4:  # RGBA
        img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)
    
    # Resize with bilinear interpolation
    resized = cv2.resize(img_array, target_size, interpolation=cv2.INTER_LINEAR)
    
    # Convert float and apply MobileNetV2 scaling (maps [0, 255] to [-1, 1])
    preprocessed = mobilenet_preprocess(resized.astype(np.float32))
    
    # Add batch dimension
    batched = np.expand_dims(preprocessed, axis=0)
    return batched


def preprocess_pil_image(pil_image: Image.Image, target_size: tuple[int, int] = IMG_SIZE) -> np.ndarray:
    """Preprocesses a PIL Image for model prediction."""
    rgb_image = pil_image.convert("RGB")
    resized = rgb_image.resize(target_size, Image.Resampling.BILINEAR)
    img_array = np.array(resized, dtype=np.float32)
    preprocessed = mobilenet_preprocess(img_array)
    batched = np.expand_dims(preprocessed, axis=0)
    return batched


if __name__ == "__main__":
    print("Preprocess module test...")
    dummy = np.random.randint(0, 256, (300, 400, 3), dtype=np.uint8)
    processed = preprocess_numpy_image(dummy)
    print(f"Input shape: (300, 400, 3) -> Output shape: {processed.shape}, Min: {processed.min():.2f}, Max: {processed.max():.2f}")
