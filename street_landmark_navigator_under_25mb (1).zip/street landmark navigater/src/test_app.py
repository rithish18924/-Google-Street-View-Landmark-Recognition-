"""
Test suite for Streamlit web application.
Launches Streamlit in headless mode, queries endpoint, and verifies startup.
"""

import subprocess
import time
import urllib.request
import sys
from pathlib import Path


def test_streamlit_server():
    print("[*] Launching Streamlit web application on port 8501...")
    proc = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", "app/app.py", "--server.port", "8501", "--server.headless", "true"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    time.sleep(5)  # Allow server to initialize

    try:
        url = "http://localhost:8501"
        req = urllib.request.Request(url, headers={"User-Agent": "TestClient"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            code = resp.status
            content = resp.read().decode("utf-8")
            print(f"[*] Streamlit Response Status Code: {code}")
            if code == 200 and "Streamlit" in content:
                print("✅ Streamlit application is healthy, active, and rendering HTML properly!")
                return True
            else:
                print(f"[!] Unexpected response content: {content[:200]}")
                return False
    except Exception as exc:
        print(f"[!] Server connection failed: {exc}")
        return False
    finally:
        print("[*] Terminating test server process...")
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    success = test_streamlit_server()
    if not success:
        sys.exit(1)
