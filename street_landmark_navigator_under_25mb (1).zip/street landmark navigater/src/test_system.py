"""
Stage 6: Comprehensive Testing Suite
Tests inference with known landmark images, unknown/non-landmark scenes,
corrupted/invalid image files, and thresholding behavior.
"""

import os
import sys
import json
import unittest
from pathlib import Path
import numpy as np
from PIL import Image

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from src.preprocess import preprocess_pil_image, IMG_SIZE
from src.utils import validate_and_open_image, get_landmark_info, LANDMARK_INFO


class LandmarkRecognitionTestSuite(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.models_dir = WORKSPACE_ROOT / "models"
        cls.model_path = cls.models_dir / "landmark_mobilenetv2_best.keras"
        if not cls.model_path.exists():
            cls.model_path = cls.models_dir / "landmark_mobilenetv2.keras"
        
        cls.labels_path = cls.models_dir / "class_labels.json"
        
        # Verify model files exist
        assert cls.model_path.exists(), f"Model file missing: {cls.model_path}"
        assert cls.labels_path.exists(), f"Labels file missing: {cls.labels_path}"
        
        cls.model = tf.keras.models.load_model(str(cls.model_path))
        with open(cls.labels_path, "r", encoding="utf-8") as f:
            cls.label_map = json.load(f)
        cls.class_names = [cls.label_map[str(i)] for i in range(len(cls.label_map))]
        print(f"\n[Test Setup] Loaded model with classes: {cls.class_names}")

    def test_01_preprocessing_dimensions_and_scaling(self):
        """Verifies that preprocessing converts arbitrary images to (1, 224, 224, 3) and [-1, 1]."""
        test_img = Image.new("RGB", (640, 480), color=(128, 64, 200))
        tensor = preprocess_pil_image(test_img, target_size=IMG_SIZE)
        
        self.assertEqual(tensor.shape, (1, 224, 224, 3), "Tensor shape must be (1, 224, 224, 3)")
        self.assertTrue(-1.0 <= tensor.min() <= 1.0, "Scaled values must fall within MobileNetV2 range")
        self.assertTrue(-1.0 <= tensor.max() <= 1.0, "Scaled values must fall within MobileNetV2 range")
        print("✅ test_01_preprocessing_dimensions_and_scaling passed.")

    def test_02_known_landmarks_inference(self):
        """Verifies prediction on known landmark demo images."""
        known_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "known"
        self.assertTrue(known_dir.exists(), "Known samples directory exists")
        
        test_files = list(known_dir.glob("*.jpg"))
        self.assertGreater(len(test_files), 0, "At least one known demo image should exist")

        correct_count = 0
        for fpath in test_files:
            pil_img, msg = validate_and_open_image(fpath)
            self.assertIsNotNone(pil_img, f"Failed opening known image {fpath.name}: {msg}")
            
            tensor = preprocess_pil_image(pil_img)
            probs = self.model.predict(tensor, verbose=0)[0]
            top_idx = int(np.argmax(probs))
            predicted_class = self.class_names[top_idx]
            conf = float(probs[top_idx])

            # Expected class is in filename prefix e.g. eiffel_tower_demo.jpg
            expected_prefix = fpath.stem.replace("_demo", "")
            if expected_prefix in predicted_class or predicted_class in expected_prefix:
                correct_count += 1
            print(f"   [Known Test] {fpath.name:<25} -> Pred: {predicted_class:<20} Conf: {conf*100:.2f}%")

        accuracy_demo = correct_count / len(test_files)
        print(f"   Known demo accuracy: {accuracy_demo * 100:.1f}% ({correct_count}/{len(test_files)})")
        self.assertGreaterEqual(accuracy_demo, 0.70, "Demo landmark accuracy should exceed 70%")
        print("✅ test_02_known_landmarks_inference passed.")

    def test_03_unknown_scenes_thresholding(self):
        """Verifies that non-landmark images with confidence < threshold are tagged as Unknown Landmark."""
        unknown_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "unknown"
        if not unknown_dir.exists():
            self.skipTest("Unknown directory not found")

        threshold = 0.60
        unknown_files = list(unknown_dir.glob("*.jpg"))
        self.assertGreater(len(unknown_files), 0, "At least one unknown test sample exists")

        flagged_unknown = 0
        for fpath in unknown_files:
            pil_img, msg = validate_and_open_image(fpath)
            if pil_img is None:
                continue
            tensor = preprocess_pil_image(pil_img)
            probs = self.model.predict(tensor, verbose=0)[0]
            top_idx = int(np.argmax(probs))
            conf = float(probs[top_idx])

            is_unknown = conf < threshold
            if is_unknown:
                flagged_unknown += 1
            label = "Unknown Landmark" if is_unknown else self.class_names[top_idx]
            print(f"   [Unknown Test] {fpath.name:<22} -> Conf: {conf*100:.2f}% -> Label: {label}")

        rejection_rate = flagged_unknown / len(unknown_files)
        print(f"   Unknown rejection rate at {threshold*100:.0f}% threshold: {rejection_rate * 100:.1f}%")
        self.assertGreaterEqual(rejection_rate, 0.50, "Most non-landmark scenes should be rejected as Unknown")
        print("✅ test_03_unknown_scenes_thresholding passed.")

    def test_04_corrupted_images_handling(self):
        """Verifies that invalid or corrupted byte payloads are caught by validate_and_open_image without crashing."""
        corrupt_dir = WORKSPACE_ROOT / "dataset" / "sample_tests" / "corrupted"
        self.assertTrue(corrupt_dir.exists(), "Corrupted samples directory exists")

        for fpath in corrupt_dir.iterdir():
            if not fpath.is_file():
                continue
            pil_img, err_msg = validate_and_open_image(fpath)
            self.assertIsNone(pil_img, f"File {fpath.name} was supposed to be rejected")
            self.assertIsInstance(err_msg, str)
            self.assertGreater(len(err_msg), 0)
            print(f"   [Corruption Test] {fpath.name:<30} -> Safely Caught: '{err_msg}'")
        print("✅ test_04_corrupted_images_handling passed.")

    def test_05_geographical_knowledge_base(self):
        """Verifies that geographical dossiers are complete for all 8 landmark categories."""
        for name in self.class_names:
            info = get_landmark_info(name)
            self.assertIn("name", info)
            self.assertIn("city", info)
            self.assertIn("country", info)
            self.assertIn("latitude", info)
            self.assertIn("longitude", info)
            self.assertIn("trivia", info)
            self.assertNotEqual(info["latitude"], 0.0, f"Latitude must be populated for {name}")
            self.assertNotEqual(info["longitude"], 0.0, f"Longitude must be populated for {name}")
        print("✅ test_05_geographical_knowledge_base passed.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
