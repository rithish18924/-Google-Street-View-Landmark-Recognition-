"""
Stage 3: Training Pipeline for Landmark Recognition Model
Trains MobileNetV2 transfer learning model on curated landmark datasets,
executes learning rate scheduling, early stopping, and exports model artifacts.
"""

import os
import sys
import json
import argparse
from pathlib import Path

# Setup workspace root in path and local keras home
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
from src.preprocess import sanitize_dataset_directory
from src.data_loader import create_data_pipeline, save_class_mappings
from src.model import build_landmark_classifier


def train_model(
    dataset_dir: str = "dataset",
    models_dir: str = "models",
    epochs: int = 15,
    batch_size: int = 16,
    learning_rate: float = 3e-4,
    fine_tune: bool = False
):
    print("=" * 65)
    print("STAGE 3: MODEL TRAINING (MobileNetV2 Transfer Learning)")
    print("=" * 65)

    dataset_path = Path(dataset_dir)
    models_path = Path(models_dir)
    models_path.mkdir(parents=True, exist_ok=True)

    # 1. Sanitize dataset directory
    print("\n[*] Sanitizing dataset to eliminate any corrupt files...")
    train_clean = sanitize_dataset_directory(dataset_path / "train")
    val_clean = sanitize_dataset_directory(dataset_path / "val")
    test_clean = sanitize_dataset_directory(dataset_path / "test")
    print(f"    Train: {train_clean['valid']} valid, {train_clean['corrupted']} corrupted removed.")
    print(f"    Val:   {val_clean['valid']} valid, {val_clean['corrupted']} corrupted removed.")
    print(f"    Test:  {test_clean['valid']} valid, {test_clean['corrupted']} corrupted removed.")

    # 2. Build tf.data pipelines
    print("\n[*] Initializing high-throughput data pipelines...")
    train_ds, val_ds, test_ds, class_names = create_data_pipeline(
        dataset_dir=dataset_path,
        batch_size=batch_size,
        augment_training=True
    )
    num_classes = len(class_names)
    save_class_mappings(class_names, models_path / "class_labels.json")

    # 3. Construct Model
    print(f"\n[*] Constructing MobileNetV2 Transfer Learning Model for {num_classes} classes...")
    model = build_landmark_classifier(
        num_classes=num_classes,
        learning_rate=learning_rate,
        freeze_base=True,
        dropout_rate=0.35
    )

    # Save summary
    with open(models_path / "model_summary.txt", "w", encoding="utf-8") as f:
        model.summary(print_fn=lambda x: f.write(x + "\n"))

    # 4. Callbacks
    best_model_path = models_path / "landmark_mobilenetv2_best.keras"
    final_model_path = models_path / "landmark_mobilenetv2.keras"

    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=5,
            restore_best_weights=True,
            verbose=1
        ),
        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(best_model_path),
            monitor="val_loss",
            save_best_only=True,
            verbose=1
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=2,
            min_lr=1e-6,
            verbose=1
        )
    ]

    # 5. Execute Training
    print(f"\n[*] Commencing Model Training for up to {epochs} epochs...")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=callbacks,
        verbose=1
    )

    # 6. Save final model and history metrics
    print(f"\n[*] Saving trained model to {final_model_path}...")
    model.save(str(final_model_path))

    # Serialize history
    history_dict = {k: [float(val) for val in v] for k, v in history.history.items()}
    history_file = models_path / "training_history.json"
    with open(history_file, "w", encoding="utf-8") as f:
        json.dump(history_dict, f, indent=4)
    print(f"[*] Training history saved to {history_file}")

    print("\n" + "=" * 65)
    print("MODEL TRAINING COMPLETED SUCCESSFULLY")
    print("=" * 65)

    return model, history_dict


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Landmark Recognition Model")
    parser.add_argument("--epochs", type=int, default=15, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="Training batch size")
    parser.add_argument("--lr", type=float, default=3e-4, help="Learning rate")
    args = parser.parse_args()

    train_model(epochs=args.epochs, batch_size=args.batch_size, learning_rate=args.lr)
