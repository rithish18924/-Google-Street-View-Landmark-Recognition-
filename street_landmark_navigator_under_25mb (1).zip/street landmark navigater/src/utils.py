"""
Utility functions and Landmark Knowledge Base for Google Street View – Landmark Recognition
"""

import os
import json
import numpy as np
from pathlib import Path
from PIL import Image

# Ensure local KERAS_HOME within workspace to prevent permission conflicts
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
os.environ["KERAS_HOME"] = str(WORKSPACE_ROOT / ".keras")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"


# Comprehensive Geographical & Historical Knowledge Base
LANDMARK_INFO = {
    "eiffel_tower": {
        "name": "Eiffel Tower",
        "native_name": "Tour Eiffel",
        "city": "Paris",
        "country": "France",
        "continent": "Europe",
        "latitude": 48.8584,
        "longitude": 2.2945,
        "completed_year": "1889",
        "architect": "Gustave Eiffel, Maurice Koechlin, Émile Nouguier",
        "height_m": 330,
        "style": "Wrought-iron Lattice Architecture",
        "street_view_url": "https://www.google.com/maps/@48.8583701,2.2944813,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1QipN...",
        "summary": "The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. Named after engineer Gustave Eiffel, it was constructed from 1887 to 1889 as the centerpiece of the 1889 World's Fair.",
        "trivia": "During the German occupation of Paris in WWII, the French Resistance cut the elevator cables so Hitler would have to climb the 1,665 stairs to the top."
    },
    "taj_mahal": {
        "name": "Taj Mahal",
        "native_name": "ताज महल",
        "city": "Agra",
        "country": "India",
        "continent": "Asia",
        "latitude": 27.1751,
        "longitude": 78.0421,
        "completed_year": "1648",
        "architect": "Ustad Ahmad Lahori",
        "height_m": 73,
        "style": "Mughal Architecture (Indo-Islamic)",
        "street_view_url": "https://www.google.com/maps/@27.175015,78.042155,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "An ivory-white marble mausoleum on the south bank of the Yamuna river. Commissioned in 1631 by Mughal emperor Shah Jahan to house the tomb of his favorite wife, Mumtaz Mahal.",
        "trivia": "The minarets surrounding the Taj Mahal are slightly tilted outwards rather than standing perfectly upright, designed so that in an earthquake they would collapse away from the central dome."
    },
    "colosseum": {
        "name": "Colosseum",
        "native_name": "Colosseo",
        "city": "Rome",
        "country": "Italy",
        "continent": "Europe",
        "latitude": 41.8902,
        "longitude": 12.4922,
        "completed_year": "80 AD",
        "architect": "Commissioned by Emperor Vespasian, completed by Titus",
        "height_m": 48,
        "style": "Ancient Imperial Roman Architecture",
        "street_view_url": "https://www.google.com/maps/@41.890210,12.492231,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "The largest ancient amphitheatre ever built. Constructed of travertine limestone, tuff, and brick-faced concrete, it could hold an estimated 50,000 to 80,000 spectators for gladiatorial contests.",
        "trivia": "The Colosseum had a massive retractable fabric awning called the velarium, operated by Roman sailors, to shield the spectators from the scorching sun."
    },
    "statue_of_liberty": {
        "name": "Statue of Liberty",
        "native_name": "Liberty Enlightening the World",
        "city": "New York City",
        "country": "United States",
        "continent": "North America",
        "latitude": 40.6892,
        "longitude": -74.0445,
        "completed_year": "1886",
        "architect": "Frédéric-Auguste Bartholdi (Sculptor), Gustave Eiffel (Framework)",
        "height_m": 93,
        "style": "Neoclassical / Copper repoussé",
        "street_view_url": "https://www.google.com/maps/@40.689249,-74.044500,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "A colossal neoclassical copper sculpture on Liberty Island in New York Harbor. Dedicated on October 28, 1886, it was a gift from the people of France to the United States.",
        "trivia": "The statue's exterior is made of copper only about 2.4 mm (3/32 inch) thick—roughly the thickness of two pennies pressed together. Its green color is the natural patina formed through oxidation."
    },
    "great_wall_of_china": {
        "name": "Great Wall of China",
        "native_name": "万里长城 (Wànlǐ Chángchéng)",
        "city": "Huairou / Beijing",
        "country": "China",
        "continent": "Asia",
        "latitude": 40.4319,
        "longitude": 116.5704,
        "completed_year": "14th Century (Ming Dynasty sections)",
        "architect": "Various Dynasties (Qin, Han, Ming)",
        "height_m": 8,
        "style": "Ancient Military Fortification",
        "street_view_url": "https://www.google.com/maps/@40.431908,116.570374,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "A series of fortifications that were built across the historical northern borders of ancient Chinese states and Imperial China as protection against various nomadic groups.",
        "trivia": "Sticky rice flour was used as an ingredient in the mortar binding the stones during the Ming dynasty, making the wall remarkably durable against seismic activity."
    },
    "big_ben": {
        "name": "Big Ben & Elizabeth Tower",
        "native_name": "Elizabeth Tower",
        "city": "London",
        "country": "United Kingdom",
        "continent": "Europe",
        "latitude": 51.5007,
        "longitude": -0.1246,
        "completed_year": "1859",
        "architect": "Augustus Pugin, Charles Barry",
        "height_m": 96,
        "style": "Gothic Revival Architecture",
        "street_view_url": "https://www.google.com/maps/@51.500729,-0.124625,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "Big Ben is the nickname for the Great Bell of the Great Clock of Westminster at the north end of the Houses of Parliament in London. The clock tower was officially renamed Elizabeth Tower in 2012.",
        "trivia": "A stack of British old penny coins is placed atop the giant pendulum to regulate its speed. Adding or removing a single coin alters the clock's speed by 0.4 seconds per day."
    },
    "pyramids_of_giza": {
        "name": "Great Pyramids of Giza",
        "native_name": "أهرامات الجيزة",
        "city": "Giza (near Cairo)",
        "country": "Egypt",
        "continent": "Africa",
        "latitude": 29.9792,
        "longitude": 31.1342,
        "completed_year": "c. 2560 BC",
        "architect": "Hemiunu (Vizier to Pharaoh Khufu)",
        "height_m": 138.8,
        "style": "Ancient Egyptian Monumental Architecture",
        "street_view_url": "https://www.google.com/maps/@29.979234,31.134202,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "The oldest and largest of the pyramids in the Giza pyramid complex. It is the oldest of the Seven Wonders of the Ancient World, and the only one to remain largely intact.",
        "trivia": "It was originally encased in highly polished white Tura limestone that reflected the desert sunlight like a gemstone, making it visible from miles away."
    },
    "sydney_opera_house": {
        "name": "Sydney Opera House",
        "native_name": "Sydney Opera House",
        "city": "Sydney",
        "country": "Australia",
        "continent": "Oceania",
        "latitude": -33.8568,
        "longitude": 151.2153,
        "completed_year": "1973",
        "architect": "Jørn Utzon",
        "height_m": 65,
        "style": "Expressionist Modernist Architecture",
        "street_view_url": "https://www.google.com/maps/@-33.856784,151.215297,3a,75y,90t/data=!3m8!1e1!3m6!1sAF1Qip...",
        "summary": "A multi-venue performing arts centre in Sydney. Located on Bennelong Point in Sydney Harbour, it is widely regarded as one of the world's most famous and distinctive buildings.",
        "trivia": "The famous roof 'shells' are covered in more than 1 million glazed Swedish ceramic tiles that are self-cleaning under rain."
    }
}


def get_landmark_info(label: str) -> dict:
    """Retrieve metadata dictionary for a given landmark key."""
    normalized = label.lower().strip().replace(" ", "_").replace("-", "_")
    return LANDMARK_INFO.get(normalized, {
        "name": label.replace("_", " ").title(),
        "city": "Unknown",
        "country": "Unknown",
        "continent": "Unknown",
        "latitude": 0.0,
        "longitude": 0.0,
        "completed_year": "N/A",
        "architect": "N/A",
        "height_m": 0,
        "style": "Architectural Landmark",
        "summary": f"Identified landmark: {label.replace('_', ' ').title()}.",
        "trivia": "Geographical coordinates and trivia pending updates."
    })


def validate_and_open_image(image_input) -> tuple[Image.Image | None, str]:
    """
    Safely open and validate an image from filepath, bytes, or file-like stream.
    Returns (PIL.Image or None, status_message).
    Detects corrupted headers, truncated data, and non-image formats.
    """
    try:
        if isinstance(image_input, (str, Path)):
            path = Path(image_input)
            if not path.exists():
                return None, f"File does not exist: {path}"
            if path.stat().st_size == 0:
                return None, "File is completely empty (0 bytes)."
            with open(path, "rb") as f:
                img_bytes = f.read()
        elif hasattr(image_input, "read"):
            img_bytes = image_input.read()
            if hasattr(image_input, "seek"):
                image_input.seek(0)
        elif isinstance(image_input, (bytes, bytearray)):
            img_bytes = image_input
        else:
            return None, "Unsupported input type."

        if len(img_bytes) < 32:
            return None, "Corrupted image: Header byte length is too short."

        import io
        stream = io.BytesIO(img_bytes)
        img = Image.open(stream)
        img.verify()  # Check for corruption

        # Reopen after verify() closes the stream
        stream.seek(0)
        img = Image.open(stream).convert("RGB")
        w, h = img.size
        if w < 16 or h < 16:
            return None, f"Image dimensions too small ({w}x{h})."
        
        return img, "Success"
    except Exception as exc:
        return None, f"Corrupted or invalid image: {str(exc)}"
